//
//  PubliciteSdk.h
//  PubliciteSdk
//
//  Created by Sunday Okpoluaefe on 9/17/19.
//  Copyright © 2019 cyberspace. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PubliciteSdk.
FOUNDATION_EXPORT double PubliciteSdkVersionNumber;

//! Project version string for PubliciteSdk.
FOUNDATION_EXPORT const unsigned char PubliciteSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PubliciteSdk/PublicHeader.h>


